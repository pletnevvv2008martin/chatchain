'use client';

interface User {
  id: string;
  nickname: string;
  status: 'guest' | 'participant' | 'king' | 'legend';
}

interface InviteModalProps {
  isOpen: boolean;
  roomName: string;
  users: User[];
  onClose: () => void;
  onInvite: (userId: string) => void;
}

export default function InviteModal({ isOpen, roomName, users, onClose, onInvite }: InviteModalProps) {
  if (!isOpen) return null;

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal-content" onClick={(e) => e.stopPropagation()}>
        <div className="modal-header">
          <h3>📨 Пригласить в комнату</h3>
          <button className="close-modal-btn" onClick={onClose}>✕</button>
        </div>

        <div className="modal-body">
          <p className="modal-description">
            Пригласить пользователей в <strong>{roomName}</strong>
          </p>

          <div className="users-list">
            {users.length > 0 ? (
              users.map((user) => (
                <div key={user.id} className="user-list-item">
                  <div className="user-list-info">
                    <span className="user-list-name">{user.nickname}</span>
                    <span className={`user-list-status status-${user.status}`}>
                      {user.status === 'guest' && '👤 Гость'}
                      {user.status === 'participant' && '⭐ Участник'}
                      {user.status === 'king' && '👑 Король'}
                      {user.status === 'legend' && '🏆 Легенда'}
                    </span>
                  </div>
                  <button
                    className="invite-btn"
                    onClick={() => onInvite(user.id)}
                  >
                    Пригласить
                  </button>
                </div>
              ))
            ) : (
              <p className="no-users">Нет пользователей для приглашения</p>
            )}
          </div>

          <div className="modal-actions">
            <button className="cancel-btn" onClick={onClose}>Закрыть</button>
          </div>
        </div>
      </div>
    </div>
  );
}
