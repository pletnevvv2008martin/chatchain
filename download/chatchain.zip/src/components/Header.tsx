'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { useState } from 'react';

interface HeaderProps {
  nickname?: string;
  onlineCount?: number;
}

export default function Header({ nickname = 'Гость', onlineCount = 1 }: HeaderProps) {
  const pathname = usePathname();
  const [isDark, setIsDark] = useState(() => {
    if (typeof window !== 'undefined') {
      const theme = localStorage.getItem('theme');
      if (theme === 'dark') {
        document.body.classList.add('dark-theme');
        return true;
      }
    }
    return false;
  });

  const toggleTheme = () => {
    const newIsDark = !isDark;
    setIsDark(newIsDark);
    if (newIsDark) {
      document.body.classList.add('dark-theme');
      localStorage.setItem('theme', 'dark');
    } else {
      document.body.classList.remove('dark-theme');
      localStorage.setItem('theme', 'light');
    }
  };

  const getActivePage = () => {
    if (pathname === '/') return 'chat';
    if (pathname === '/game') return 'game';
    if (pathname === '/dating') return 'dating';
    return 'chat';
  };

  return (
    <header className="main-header">
      <div className="header-content">
        <div className="logo">
          <h1>Chat<span>Chain</span></h1>
        </div>

        <nav className="header-nav">
          <Link href="/" className={`nav-link ${getActivePage() === 'chat' ? 'active' : ''}`}>
            Чат
          </Link>
          <Link href="/game" className={`nav-link ${getActivePage() === 'game' ? 'active' : ''}`}>
            Игра
          </Link>
          <Link href="/dating" className={`nav-link ${getActivePage() === 'dating' ? 'active' : ''}`}>
            Знакомства
          </Link>
        </nav>

        <div className="user-info">
          <span className="online-count">
            <span className="dot"></span>
            <span>{onlineCount}</span>
          </span>
          <span className="user-nickname">{nickname}</span>
          <button className="theme-toggle" onClick={toggleTheme}>
            <span className="theme-icon">{isDark ? '☀️' : '🌙'}</span>
          </button>
        </div>
      </div>
    </header>
  );
}
