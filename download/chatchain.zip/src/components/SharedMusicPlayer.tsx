'use client';

import React, { useState, useCallback, useRef, useEffect } from 'react';
import {
  getThumbnail as getYoutubeThumbnail,
  extractVideoId,
  YOUTUBE_PLAYER_STATES
} from '@/lib/youtube';
import {
  extractSoundCloudId
} from '@/lib/soundcloud';

// Track type
interface SharedTrack {
  id: string;
  title: string;
  thumbnail: string;
  duration: string;
  durationMs: number;
  source: 'youtube' | 'soundcloud';
  sourceId: string;
  addedBy: string;
  addedByName: string;
  addedAt: number;
}

interface MusicState {
  currentTrack: SharedTrack | null;
  queue: SharedTrack[];
  isPlaying: boolean;
  currentTime: number;
  volume: number;
  djUserId: string | null;
  lastUpdate: number;
}

interface SharedMusicPlayerProps {
  currentUserId: string;
  currentUserName: string;
}

// YouTube Player Types
interface YTPlayer {
  playVideo: () => void;
  pauseVideo: () => void;
  seekTo: (seconds: number, allowSeekAhead?: boolean) => void;
  setVolume: (volume: number) => void;
  getDuration: () => number;
  getCurrentTime: () => number;
  getPlayerState: () => number;
  mute: () => void;
  unMute: () => void;
  isMuted: () => boolean;
  destroy: () => void;
}

declare global {
  interface Window {
    YT: {
      Player: new (
        elementId: string,
        config: {
          height: string;
          width: string;
          videoId: string;
          playerVars?: Record<string, number>;
          events?: {
            onReady?: (event: { target: YTPlayer }) => void;
            onStateChange?: (event: { data: number; target: YTPlayer }) => void;
            onError?: (event: { data: number }) => void;
          };
        }
      ) => YTPlayer;
      PlayerState: Record<string, number>;
    };
    SC: {
      Widget: new (iframe: HTMLIFrameElement | string) => SoundCloudWidget;
    };
  }
}

interface SoundCloudWidget {
  bind: (event: string, callback: (data?: unknown) => void) => void;
  load: (url: string, options?: Record<string, unknown>) => void;
  play: () => void;
  pause: () => void;
  toggle: () => void;
  seekTo: (ms: number) => void;
  setVolume: (volume: number) => void;
}

export function SharedMusicPlayer({ currentUserId, currentUserName }: SharedMusicPlayerProps) {
  // State
  const [serverState, setServerState] = useState<MusicState | null>(null);
  const [inputValue, setInputValue] = useState('');
  const [showQueue, setShowQueue] = useState(false);
  const [localCurrentTime, setLocalCurrentTime] = useState(0);
  const [localDuration, setLocalDuration] = useState(0);
  const [localVolume, setLocalVolume] = useState(100);
  const [isMuted, setIsMuted] = useState(false);
  const [source, setSource] = useState<'youtube' | 'soundcloud'>('youtube');

  // Refs
  const youtubePlayerRef = useRef<YTPlayer | null>(null);
  const soundcloudPlayerRef = useRef<SoundCloudWidget | null>(null);
  const soundcloudIframeRef = useRef<HTMLIFrameElement | null>(null);
  const youtubePlayerId = 'youtube-player-shared';
  const soundcloudPlayerId = 'soundcloud-player-shared';
  const progressIntervalRef = useRef<NodeJS.Timeout | null>(null);
  const syncIntervalRef = useRef<NodeJS.Timeout | null>(null);
  const lastSyncTimeRef = useRef(0);

  // Load APIs
  useEffect(() => {
    if (typeof window !== 'undefined' && !window.YT) {
      const tag = document.createElement('script');
      tag.src = 'https://www.youtube.com/iframe_api';
      const firstScript = document.getElementsByTagName('script')[0];
      firstScript.parentNode?.insertBefore(tag, firstScript);
    }

    if (typeof window !== 'undefined' && !window.SC) {
      const tag = document.createElement('script');
      tag.src = 'https://w.soundcloud.com/player/api.js';
      const firstScript = document.getElementsByTagName('script')[0];
      firstScript.parentNode?.insertBefore(tag, firstScript);
    }
  }, []);

  // Sync with server
  const syncWithServer = useCallback(async () => {
    try {
      const response = await fetch('/api/music');
      const data = await response.json();
      if (data.success) {
        setServerState(data.state);
      }
    } catch (error) {
      console.error('Sync error:', error);
    }
  }, []);

  // Initial sync and polling
  useEffect(() => {
    // eslint-disable-next-line react-hooks/set-state-in-effect
    syncWithServer();
    syncIntervalRef.current = setInterval(syncWithServer, 1000);
    return () => {
      if (syncIntervalRef.current) {
        clearInterval(syncIntervalRef.current);
      }
    };
  }, [syncWithServer]);

  // Send action to server
  const sendAction = useCallback(async (action: string, data: Record<string, unknown> = {}) => {
    try {
      await fetch('/api/music', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action,
          userId: currentUserId,
          userName: currentUserName,
          ...data,
        }),
      });
      syncWithServer();
    } catch (error) {
      console.error('Action error:', error);
    }
  }, [currentUserId, currentUserName, syncWithServer]);

  // Initialize YouTube player for current track
  useEffect(() => {
    if (!serverState?.currentTrack || serverState.currentTrack.source !== 'youtube') return;

    const videoId = serverState.currentTrack.sourceId;

    const initPlayer = () => {
      if (youtubePlayerRef.current) {
        youtubePlayerRef.current.destroy();
      }

      youtubePlayerRef.current = new window.YT.Player(youtubePlayerId, {
        height: '0',
        width: '0',
        videoId: videoId,
        playerVars: {
          autoplay: 0,
          controls: 0,
          disablekb: 1,
          fs: 0,
          modestbranding: 1,
          rel: 0,
        },
        events: {
          onReady: () => {
            if (serverState.isPlaying) {
              youtubePlayerRef.current?.playVideo();
              youtubePlayerRef.current?.seekTo(serverState.currentTime, true);
            }
            youtubePlayerRef.current?.setVolume(localVolume);
          },
          onStateChange: (event) => {
            const state = YOUTUBE_PLAYER_STATES[event.data];

            if (state === 'playing') {
              if (progressIntervalRef.current) {
                clearInterval(progressIntervalRef.current);
              }
              progressIntervalRef.current = setInterval(() => {
                if (youtubePlayerRef.current) {
                  const time = youtubePlayerRef.current.getCurrentTime();
                  const dur = youtubePlayerRef.current.getDuration();
                  setLocalCurrentTime(time);
                  setLocalDuration(dur);

                  // Sync time to server every 5 seconds
                  if (Math.abs(time - lastSyncTimeRef.current) > 5) {
                    lastSyncTimeRef.current = time;
                    sendAction('sync_time', { time });
                  }
                }
              }, 1000);
            } else if (state === 'ended') {
              sendAction('track_ended');
            } else {
              if (progressIntervalRef.current) {
                clearInterval(progressIntervalRef.current);
              }
            }
          },
          onError: (e) => console.error('YouTube error:', e.data),
        },
      });
    };

    if (window.YT && window.YT.Player) {
      initPlayer();
    } else {
      const checkYT = setInterval(() => {
        if (window.YT && window.YT.Player) {
          clearInterval(checkYT);
          initPlayer();
        }
      }, 100);
    }

    return () => {
      if (progressIntervalRef.current) {
        clearInterval(progressIntervalRef.current);
      }
    };
  }, [serverState?.currentTrack?.id, serverState?.isPlaying, serverState?.currentTime, localVolume, sendAction]);

  // Initialize SoundCloud player
  useEffect(() => {
    if (!serverState?.currentTrack || serverState.currentTrack.source !== 'soundcloud') return;

    const initSoundCloud = () => {
      if (window.SC && soundcloudIframeRef.current) {
        soundcloudPlayerRef.current = new window.SC.Widget(soundcloudIframeRef.current);

        soundcloudPlayerRef.current.bind('ready', () => {
          if (serverState.isPlaying) {
            soundcloudPlayerRef.current?.play();
          }
        });

        soundcloudPlayerRef.current.bind('playProgress', (data: unknown) => {
          const progressData = data as { currentPosition: number };
          if (progressData?.currentPosition) {
            setLocalCurrentTime(progressData.currentPosition / 1000);
          }
        });

        soundcloudPlayerRef.current.bind('finish', () => {
          sendAction('track_ended');
        });
      }
    };

    if (window.SC) {
      initSoundCloud();
    } else {
      const checkSC = setInterval(() => {
        if (window.SC && soundcloudIframeRef.current) {
          clearInterval(checkSC);
          initSoundCloud();
        }
      }, 100);
    }
  }, [serverState?.currentTrack?.id, serverState?.isPlaying, sendAction]);

  // Sync play/pause state
  useEffect(() => {
    if (!serverState?.currentTrack) return;

    if (serverState.currentTrack.source === 'youtube' && youtubePlayerRef.current) {
      if (serverState.isPlaying) {
        youtubePlayerRef.current.playVideo();
      } else {
        youtubePlayerRef.current.pauseVideo();
      }
    } else if (serverState.currentTrack.source === 'soundcloud' && soundcloudPlayerRef.current) {
      if (serverState.isPlaying) {
        soundcloudPlayerRef.current.play();
      } else {
        soundcloudPlayerRef.current.pause();
      }
    }
  }, [serverState?.isPlaying, serverState?.currentTrack]);

  // Add track
  const handleAddTrack = useCallback(async () => {
    if (!inputValue.trim()) return;

    const youtubeId = extractVideoId(inputValue);
    if (youtubeId) {
      const track = {
        id: `yt-${youtubeId}-${Date.now()}`,
        title: 'Загрузка...',
        thumbnail: getYoutubeThumbnail(youtubeId),
        duration: '',
        durationMs: 0,
        source: 'youtube' as const,
        sourceId: youtubeId,
      };
      await sendAction('add_track', { track });
      setInputValue('');
      return;
    }

    const soundcloudUrl = extractSoundCloudId(inputValue);
    if (soundcloudUrl) {
      const track = {
        id: `sc-${Date.now()}`,
        title: 'SoundCloud трек',
        thumbnail: 'data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><rect fill="%23333" width="100" height="100"/><circle cx="50" cy="50" r="25" fill="%23555"/></svg>',
        duration: '',
        durationMs: 0,
        source: 'soundcloud' as const,
        sourceId: soundcloudUrl,
      };
      await sendAction('add_track', { track });
      setInputValue('');
      return;
    }

    // Search
    const searchQuery = encodeURIComponent(inputValue);
    if (source === 'youtube') {
      window.open(`https://www.youtube.com/results?search_query=${searchQuery}`, '_blank');
    } else {
      window.open(`https://soundcloud.com/search?q=${searchQuery}`, '_blank');
    }
  }, [inputValue, source, sendAction]);

  // Controls
  const handlePlayPause = useCallback(() => {
    if (serverState?.isPlaying) {
      sendAction('pause');
    } else {
      sendAction('play');
    }
  }, [serverState?.isPlaying, sendAction]);

  const handleSeek = useCallback((seconds: number) => {
    sendAction('seek', { time: seconds });
    if (youtubePlayerRef.current && serverState?.currentTrack?.source === 'youtube') {
      youtubePlayerRef.current.seekTo(seconds, true);
    }
    setLocalCurrentTime(seconds);
  }, [serverState?.currentTrack?.source, sendAction]);

  const handleVolumeChange = useCallback((vol: number) => {
    setLocalVolume(vol);
    if (youtubePlayerRef.current) {
      youtubePlayerRef.current.setVolume(vol);
    }
  }, []);

  const handleNext = useCallback(() => {
    sendAction('next');
  }, [sendAction]);

  const handleRemoveFromQueue = useCallback((trackId: string) => {
    sendAction('remove', { trackId });
  }, [sendAction]);

  // Format time
  const formatTime = (seconds: number): string => {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  // Is current user the DJ?
  const isDJ = serverState?.djUserId === currentUserId || !serverState?.djUserId;

  return (
    <div className="shared-music-player">
      {/* Hidden players */}
      <div id={youtubePlayerId} style={{ display: 'none' }} />
      <iframe
        ref={soundcloudIframeRef}
        id={soundcloudPlayerId}
        src="https://w.soundcloud.com/player/?url=https://soundcloud.com/"
        style={{ display: 'none' }}
        allow="autoplay"
      />

      {/* Main UI */}
      <div className="bg-[var(--bg-secondary)] rounded-xl p-4 border border-[var(--border-light)]">
        {/* Header */}
        <div className="flex items-center justify-between mb-3">
          <h3 className="text-lg font-semibold text-[var(--text-primary)]">
            Музыка
            <span className="text-xs font-normal text-[var(--text-muted)] ml-2">
              (общая)
            </span>
          </h3>

          {/* Source toggle */}
          <div className="flex gap-1 bg-[var(--bg-tertiary)] rounded-full p-1">
            <button
              onClick={() => setSource('youtube')}
              className={`px-3 py-1 rounded-full text-xs font-medium transition-colors ${
                source === 'youtube' ? 'bg-red-500 text-white' : 'text-[var(--text-secondary)]'
              }`}
            >
              YouTube
            </button>
            <button
              onClick={() => setSource('soundcloud')}
              className={`px-3 py-1 rounded-full text-xs font-medium transition-colors ${
                source === 'soundcloud' ? 'bg-orange-500 text-white' : 'text-[var(--text-secondary)]'
              }`}
            >
              SoundCloud
            </button>
          </div>
        </div>

        {/* Add track */}
        <div className="flex gap-2 mb-3">
          <input
            type="text"
            value={inputValue}
            onChange={(e) => setInputValue(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleAddTrack()}
            placeholder={source === 'youtube' ? 'Вставьте ссылку YouTube...' : 'Вставьте ссылку SoundCloud...'}
            className="flex-1 px-4 py-2 bg-[var(--bg-tertiary)] border border-[var(--border-light)] rounded-full text-sm text-[var(--text-primary)] placeholder-[var(--text-muted)] focus:outline-none focus:border-[var(--accent-primary)]"
          />
          <button
            onClick={handleAddTrack}
            className="px-4 py-2 bg-[var(--accent-primary)] text-white rounded-full text-sm font-medium hover:bg-[var(--accent-secondary)] transition-colors"
          >
            +
          </button>
        </div>

        {/* Current Track */}
        {serverState?.currentTrack && (
          <div className="p-3 bg-[var(--bg-tertiary)] rounded-lg">
            <div className="flex items-center gap-3">
              <img
                src={serverState.currentTrack.thumbnail}
                alt={serverState.currentTrack.title}
                className="w-14 h-14 rounded-lg object-cover"
              />
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2">
                  <p className="text-sm font-medium text-[var(--text-primary)] truncate">
                    {serverState.currentTrack.title}
                  </p>
                  <span className={`text-xs px-2 py-0.5 rounded ${
                    serverState.currentTrack.source === 'youtube' ? 'bg-red-500 text-white' : 'bg-orange-500 text-white'
                  }`}>
                    {serverState.currentTrack.source === 'youtube' ? 'YT' : 'SC'}
                  </span>
                </div>
                <p className="text-xs text-[var(--text-muted)]">
                  Добавил: {serverState.currentTrack.addedByName}
                </p>
                <p className="text-xs text-[var(--text-muted)]">
                  {formatTime(localCurrentTime)} / {formatTime(localDuration)}
                </p>
              </div>
            </div>

            {/* Progress Bar */}
            <div className="mt-3">
              <div
                className="h-2 bg-[var(--border-light)] rounded-full cursor-pointer overflow-hidden"
                onClick={(e) => {
                  const rect = e.currentTarget.getBoundingClientRect();
                  const percent = (e.clientX - rect.left) / rect.width;
                  handleSeek(percent * localDuration);
                }}
              >
                <div
                  className={`h-full rounded-full transition-all ${
                    serverState.currentTrack.source === 'youtube'
                      ? 'bg-gradient-to-r from-red-500 to-red-400'
                      : 'bg-gradient-to-r from-orange-500 to-orange-400'
                  }`}
                  style={{ width: `${localDuration > 0 ? (localCurrentTime / localDuration) * 100 : 0}%` }}
                />
              </div>
            </div>

            {/* Controls */}
            <div className="flex items-center justify-center gap-3 mt-3">
              <button
                onClick={() => handleSeek(Math.max(0, localCurrentTime - 10))}
                className="w-10 h-10 flex items-center justify-center text-[var(--text-secondary)] hover:text-[var(--text-primary)] hover:bg-[var(--bg-secondary)] rounded-full transition-colors"
              >
                <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24"><path d="M11 18V6l-8.5 6 8.5 6zm.5-6l8.5 6V6l-8.5 6z"/></svg>
              </button>
              <button
                onClick={handlePlayPause}
                className={`w-14 h-14 flex items-center justify-center rounded-full text-white text-xl transition-colors ${
                  serverState.currentTrack.source === 'youtube'
                    ? 'bg-red-500 hover:bg-red-600'
                    : 'bg-orange-500 hover:bg-orange-600'
                }`}
              >
                {serverState.isPlaying ? (
                  <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 24 24"><rect x="6" y="4" width="4" height="16"/><rect x="14" y="4" width="4" height="16"/></svg>
                ) : (
                  <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 24 24"><path d="M8 5v14l11-7z"/></svg>
                )}
              </button>
              <button
                onClick={() => handleSeek(Math.min(localDuration, localCurrentTime + 10))}
                className="w-10 h-10 flex items-center justify-center text-[var(--text-secondary)] hover:text-[var(--text-primary)] hover:bg-[var(--bg-secondary)] rounded-full transition-colors"
              >
                <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24"><path d="M4 18l8.5-6L4 6v12zm9-12v12l8.5-6L13 6z"/></svg>
              </button>
              <button
                onClick={handleNext}
                className="w-10 h-10 flex items-center justify-center text-[var(--text-secondary)] hover:text-[var(--text-primary)] hover:bg-[var(--bg-secondary)] rounded-full transition-colors"
              >
                <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24"><path d="M6 18l8.5-6L6 6v12zM16 6v12h2V6h-2z"/></svg>
              </button>
            </div>

            {/* Volume */}
            <div className="flex items-center gap-2 mt-3">
              <button onClick={() => {
                if (isMuted) {
                  youtubePlayerRef.current?.unMute();
                  setIsMuted(false);
                } else {
                  youtubePlayerRef.current?.mute();
                  setIsMuted(true);
                }
              }} className="text-[var(--text-secondary)] text-lg">
                {isMuted ? (
                  <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24"><path d="M16.5 12c0-1.77-1.02-3.29-2.5-4.03v2.21l2.45 2.45c.03-.2.05-.41.05-.63zm2.5 0c0 .94-.2 1.82-.54 2.64l1.51 1.51C20.63 14.91 21 13.5 21 12c0-4.28-2.99-7.86-7-8.77v2.06c2.89.86 5 3.54 5 6.71zM4.27 3L3 4.27 7.73 9H3v6h4l5 5v-6.73l4.25 4.25c-.67.52-1.42.93-2.25 1.18v2.06c1.38-.31 2.63-.95 3.69-1.81L19.73 21 21 19.73l-9-9L4.27 3zM12 4L9.91 6.09 12 8.18V4z"/></svg>
                ) : (
                  <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24"><path d="M3 9v6h4l5 5V4L7 9H3zm13.5 3c0-1.77-1.02-3.29-2.5-4.03v8.05c1.48-.73 2.5-2.25 2.5-4.02zM14 3.23v2.06c2.89.86 5 3.54 5 6.71s-2.11 5.85-5 6.71v2.06c4.01-.91 7-4.49 7-8.77s-2.99-7.86-7-8.77z"/></svg>
                )}
              </button>
              <input
                type="range"
                min="0"
                max="100"
                value={isMuted ? 0 : localVolume}
                onChange={(e) => handleVolumeChange(parseInt(e.target.value))}
                className="flex-1 h-2 accent-[var(--accent-primary)] cursor-pointer"
              />
              <span className="text-xs text-[var(--text-muted)] w-8">{localVolume}%</span>
            </div>

            {/* DJ indicator */}
            {!isDJ && (
              <p className="text-xs text-center text-[var(--text-muted)] mt-2">
                Управляет: {serverState.djUserId}
              </p>
            )}
          </div>
        )}

        {/* Queue */}
        {serverState && serverState.queue.length > 0 && (
          <>
            <button
              onClick={() => setShowQueue(!showQueue)}
              className="w-full mt-4 py-2 text-sm text-[var(--text-secondary)] hover:text-[var(--text-primary)] transition-colors"
            >
              Очередь ({serverState.queue.length} треков) {showQueue ? '▲' : '▼'}
            </button>

            {showQueue && (
              <div className="mt-2 space-y-2 max-h-40 overflow-y-auto">
                {serverState.queue.map((track) => (
                  <div key={track.id} className="flex items-center gap-2 p-2 bg-[var(--bg-tertiary)] rounded-lg">
                    <img src={track.thumbnail} alt={track.title} className="w-10 h-10 rounded object-cover" />
                    <div className="flex-1 min-w-0">
                      <p className="text-xs font-medium text-[var(--text-primary)] truncate">{track.title}</p>
                      <p className="text-xs text-[var(--text-muted)]">by {track.addedByName}</p>
                    </div>
                    <button
                      onClick={() => handleRemoveFromQueue(track.id)}
                      className="w-8 h-8 flex items-center justify-center text-[var(--accent-danger)] hover:bg-[var(--bg-secondary)] rounded-full transition-colors"
                    >
                      ✕
                    </button>
                  </div>
                ))}
              </div>
            )}
          </>
        )}

        {/* Empty State */}
        {(!serverState?.currentTrack && (!serverState?.queue || serverState.queue.length === 0)) && (
          <div className="mt-4 text-center py-6 text-[var(--text-muted)]">
            <div className="flex justify-center gap-3 mb-2">
              <span className="w-6 h-6 rounded-full bg-red-500"></span>
              <span className="w-6 h-6 rounded-full bg-orange-500"></span>
            </div>
            <p className="text-sm">Вставьте ссылку на музыку</p>
            <p className="text-xs mt-1">Все услышат одну музыку</p>
          </div>
        )}

        {/* Help */}
        <div className="mt-3 text-xs text-[var(--text-muted)] text-center">
          <p>YouTube: youtube.com/watch?v=... | SoundCloud: soundcloud.com/...</p>
        </div>
      </div>
    </div>
  );
}

export default SharedMusicPlayer;
