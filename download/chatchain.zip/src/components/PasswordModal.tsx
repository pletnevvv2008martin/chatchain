'use client';

import { useState } from 'react';

interface PasswordModalProps {
  isOpen: boolean;
  roomName: string;
  onClose: () => void;
  onSubmit: (password: string) => void;
  error?: string;
}

export default function PasswordModal({ isOpen, roomName, onClose, onSubmit, error }: PasswordModalProps) {
  const [password, setPassword] = useState('');

  const handleSubmit = () => {
    onSubmit(password);
    setPassword('');
  };

  if (!isOpen) return null;

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal-content" onClick={(e) => e.stopPropagation()}>
        <div className="modal-header">
          <h3>🔐 Вход в комнату</h3>
          <button className="close-modal-btn" onClick={onClose}>✕</button>
        </div>

        <div className="modal-body">
          <p className="modal-description">
            Комната <strong>{roomName}</strong> защищена паролем
          </p>

          <div className="form-group">
            <label>Введите пароль</label>
            <input
              type="password"
              placeholder="Пароль..."
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && handleSubmit()}
              autoFocus
            />
          </div>

          {error && <p className="error-message">{error}</p>}

          <div className="modal-actions">
            <button className="cancel-btn" onClick={onClose}>Отмена</button>
            <button className="submit-btn" onClick={handleSubmit}>Войти</button>
          </div>
        </div>
      </div>
    </div>
  );
}
