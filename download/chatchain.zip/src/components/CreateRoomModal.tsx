'use client';

import { useState } from 'react';

interface CreateRoomModalProps {
  isOpen: boolean;
  onClose: () => void;
  onCreate: (name: string, password: string) => void;
}

export default function CreateRoomModal({ isOpen, onClose, onCreate }: CreateRoomModalProps) {
  const [name, setName] = useState('');
  const [password, setPassword] = useState('');
  const [hasPassword, setHasPassword] = useState(false);

  const handleSubmit = () => {
    if (!name.trim()) {
      alert('Введите название комнаты');
      return;
    }
    onCreate(name.trim(), hasPassword ? password : '');
    setName('');
    setPassword('');
    setHasPassword(false);
    onClose();
  };

  if (!isOpen) return null;

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal-content" onClick={(e) => e.stopPropagation()}>
        <div className="modal-header">
          <h3>➕ Создать комнату</h3>
          <button className="close-modal-btn" onClick={onClose}>✕</button>
        </div>

        <div className="modal-body">
          <div className="form-group">
            <label>Название комнаты</label>
            <input
              type="text"
              placeholder="Введите название..."
              value={name}
              onChange={(e) => setName(e.target.value)}
              maxLength={50}
            />
          </div>

          <div className="form-group">
            <label className="checkbox-label">
              <input
                type="checkbox"
                checked={hasPassword}
                onChange={(e) => setHasPassword(e.target.checked)}
              />
              <span>Установить пароль</span>
            </label>
          </div>

          {hasPassword && (
            <div className="form-group">
              <label>Пароль</label>
              <input
                type="password"
                placeholder="Введите пароль..."
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                maxLength={20}
              />
            </div>
          )}

          <div className="modal-actions">
            <button className="cancel-btn" onClick={onClose}>Отмена</button>
            <button className="submit-btn" onClick={handleSubmit}>Создать</button>
          </div>
        </div>
      </div>
    </div>
  );
}
