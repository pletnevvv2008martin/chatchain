import type { Metadata } from "next";
import { Inter } from "next/font/google";
import "./globals.css";

const inter = Inter({
  subsets: ["latin", "cyrillic"],
});

export const metadata: Metadata = {
  title: "ChatChain - Чат, Игра, Знакомства",
  description: "ChatChain - многопользовательский чат с играми и знакомствами",
  keywords: ["чат", "игра", "знакомства", "ChatChain"],
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="ru" suppressHydrationWarning>
      <body className={`${inter.className} antialiased`}>
        <script
          dangerouslySetInnerHTML={{
            __html: `
              (function() {
                const theme = localStorage.getItem('theme');
                if (theme === 'dark') {
                  document.body.classList.add('dark-theme');
                }
              })();
            `,
          }}
        />
        {children}
      </body>
    </html>
  );
}
