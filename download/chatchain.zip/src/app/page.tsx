'use client';

import { useState, useEffect, useRef, useCallback } from 'react';
import Header from '@/components/Header';
import RoomsSidebar from '@/components/RoomsSidebar';
import SharedMusicPlayer from '@/components/SharedMusicPlayer';
import CreateRoomModal from '@/components/CreateRoomModal';
import PasswordModal from '@/components/PasswordModal';
import InviteModal from '@/components/InviteModal';
import {
  User,
  Room,
  Message,
  getUser,
  updateUser,
  getRooms,
  saveRooms,
  createRoom,
  getAvailableLobby,
  joinRoom,
  leaveRoom,
  addMessageToRoom,
  generateId,
  getStatusEmoji,
  getStatusColor,
} from '@/lib/store';

const EMOJIS = ['😊', '😂', '🤣', '❤️', '😍', '😒', '👌', '👍', '🔥', '✨', '🎉', '💯', '⚡', '🎮', '💰', '🙏', '💪', '🤔', '😴', '🥳', '😎', '🥺', '😅', '😆', '🤝'];

const DEMO_USERS: { id: string; nickname: string; status: 'guest' | 'participant' | 'king' | 'legend' }[] = [
  { id: '1', nickname: 'Алексей', status: 'participant' },
  { id: '2', nickname: 'Мария', status: 'king' },
  { id: '3', nickname: 'Дмитрий', status: 'guest' },
  { id: '4', nickname: 'Елена', status: 'legend' },
  { id: '5', nickname: 'Сергей', status: 'participant' },
];

export default function ChatPage() {
  const [isInitialized, setIsInitialized] = useState(false);
  const [user, setUser] = useState<User | null>(null);
  const [rooms, setRooms] = useState<Room[]>([]);
  const [currentRoomId, setCurrentRoomId] = useState<string>('');
  const [messages, setMessages] = useState<Message[]>([]);
  const [inputValue, setInputValue] = useState('');
  const [showEmoji, setShowEmoji] = useState(false);
  const [typingUser, setTypingUser] = useState('');
  const [showCreateRoom, setShowCreateRoom] = useState(false);
  const [showPasswordModal, setShowPasswordModal] = useState(false);
  const [showInviteModal, setShowInviteModal] = useState(false);
  const [passwordRoom, setPasswordRoom] = useState<Room | null>(null);
  const [passwordError, setPasswordError] = useState('');
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Инициализация на клиенте
  useEffect(() => {
    if (isInitialized) return;

    const userData = getUser();
    const roomsData = getRooms();
    const lobby = getAvailableLobby();
    const result = joinRoom(lobby.id, userData.id);

    // Инициализация из localStorage - стандартный паттерн для SSR
    /* eslint-disable react-hooks/set-state-in-effect */
    setUser(userData);
    setRooms(roomsData);
    setCurrentRoomId(lobby.id);
    setMessages(result.success && result.room ? result.room.messages || [] : lobby.messages || []);
    /* eslint-enable react-hooks/set-state-in-effect */
    setIsInitialized(true);
  }, [isInitialized]);

  // Прокрутка вниз
  const scrollToBottom = useCallback(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, []);

  useEffect(() => {
    scrollToBottom();
  }, [messages, scrollToBottom]);

  // Симуляция сообщений
  useEffect(() => {
    const interval = setInterval(() => {
      if (Math.random() > 0.85) {
        const randomUser = DEMO_USERS[Math.floor(Math.random() * DEMO_USERS.length)];
        const responses = [
          'Привет всем! 👋',
          'Круто! 🔥',
          'Согласен!',
          'Кто хочет сыграть?',
          'Интересно 🤔',
          'Да, конечно!',
          'Хаха 😂',
          'Супер! ✨',
        ];
        const randomResponse = responses[Math.floor(Math.random() * responses.length)];
        const newMessage: Message = {
          id: generateId(),
          userId: randomUser.id,
          user: randomUser.nickname,
          content: randomResponse,
          time: new Date().toLocaleTimeString('ru-RU', { hour: '2-digit', minute: '2-digit' }),
          type: 'text',
          userStatus: randomUser.status,
        };

        setMessages(prev => [...prev, newMessage]);
        addMessageToRoom(currentRoomId, newMessage);
      }
    }, 10000);
    return () => clearInterval(interval);
  }, [currentRoomId]);

  // Симуляция печатания
  useEffect(() => {
    const interval = setInterval(() => {
      if (Math.random() > 0.8) {
        const randomUser = DEMO_USERS[Math.floor(Math.random() * DEMO_USERS.length)];
        setTypingUser(randomUser.nickname);
        setTimeout(() => setTypingUser(''), 2000);
      }
    }, 5000);
    return () => clearInterval(interval);
  }, []);

  const sendMessage = () => {
    if (!inputValue.trim() || !user) return;

    const newMessage: Message = {
      id: generateId(),
      userId: user.id,
      user: user.nickname,
      content: inputValue.trim(),
      time: new Date().toLocaleTimeString('ru-RU', { hour: '2-digit', minute: '2-digit' }),
      type: 'text',
      userStatus: user.status,
    };

    setMessages(prev => [...prev, newMessage]);
    addMessageToRoom(currentRoomId, newMessage);
    setInputValue('');
  };

  const addEmoji = (emoji: string) => {
    setInputValue(prev => prev + emoji);
    setShowEmoji(false);
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      sendMessage();
    }
  };

  // Комнаты
  const handleCreateRoom = (name: string, password: string) => {
    if (!user) return;
    const newRoom = createRoom(name, password, user.id);
    setRooms(getRooms());
    setCurrentRoomId(newRoom.id);
    setMessages([]);
    setShowCreateRoom(false);
  };

  const handleJoinRoom = (roomId: string) => {
    if (!user) return;

    const room = rooms.find(r => r.id === roomId);
    if (!room) return;

    if (room.password) {
      setPasswordRoom(room);
      setShowPasswordModal(true);
      return;
    }

    const result = joinRoom(roomId, user.id);
    if (result.success && result.room) {
      setCurrentRoomId(roomId);
      setMessages(result.room.messages || []);
      setRooms(getRooms());
    }
  };

  const handlePasswordSubmit = (password: string) => {
    if (!user || !passwordRoom) return;

    const result = joinRoom(passwordRoom.id, user.id, password);
    if (result.success && result.room) {
      setCurrentRoomId(passwordRoom.id);
      setMessages(result.room.messages || []);
      setRooms(getRooms());
      setShowPasswordModal(false);
      setPasswordRoom(null);
      setPasswordError('');
    } else {
      setPasswordError(result.error || 'Ошибка');
    }
  };

  const handleInvite = (targetUserId: string) => {
    alert(`Приглашение отправлено пользователю!`);
    setShowInviteModal(false);
  };

  const handlePointsUpdate = (points: number) => {
    if (!user) return;
    const updated = updateUser({ points });
    setUser(updated);
  };

  const currentRoom = rooms.find(r => r.id === currentRoomId);

  if (!user) {
    return <div className="app-container">Загрузка...</div>;
  }

  return (
    <div className="app-container" style={{ paddingBottom: '70px' }}>
      <Header nickname={user.nickname} onlineCount={currentRoom?.users.length || 0} />

      <div style={{ display: 'flex', gap: '20px', flex: 1 }}>
        {/* Сайдбар комнат */}
        <RoomsSidebar
          rooms={rooms}
          currentRoomId={currentRoomId}
          user={user}
          onJoinRoom={handleJoinRoom}
          onCreateRoom={() => setShowCreateRoom(true)}
        />

        {/* Основной чат */}
        <main className="chat-main" style={{ flex: 1, maxWidth: 'calc(100% - 520px)' }}>
          <div style={{ padding: '10px 20px', borderBottom: '1px solid var(--border-light)', background: 'var(--bg-tertiary)' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <div>
                <h3 style={{ margin: 0 }}>{currentRoom?.name || 'Чат'}</h3>
                <small style={{ color: 'var(--text-muted)' }}>{currentRoom?.users.length || 0} участников</small>
              </div>
              {!currentRoom?.isLobby && (
                <button
                  className="invite-btn"
                  onClick={() => setShowInviteModal(true)}
                >
                  📨 Пригласить
                </button>
              )}
            </div>
          </div>

          <div className="messages-container">
            {messages.map((msg) => (
              <div
                key={msg.id}
                className={`message ${
                  msg.type === 'system' ? 'system' : msg.userId === user.id ? 'own' : 'other'
                }`}
              >
                <div className="message-header">
                  <span className="message-user">
                    {msg.user}
                    {msg.userStatus && msg.userStatus !== 'guest' && (
                      <span
                        className="message-status-badge"
                        style={{ color: getStatusColor(msg.userStatus) }}
                      >
                        {getStatusEmoji(msg.userStatus)}
                      </span>
                    )}
                  </span>
                  <span className="message-time">{msg.time}</span>
                </div>
                <div className="message-content">
                  {msg.type === 'image' ? (
                    <img src={msg.content} alt="Image" />
                  ) : (
                    msg.content
                  )}
                </div>
              </div>
            ))}
            <div ref={messagesEndRef} />
          </div>

          <div className="typing-indicator">
            {typingUser && `${typingUser} печатает...`}
          </div>

          <div className="input-toolbar">
            <button className="toolbar-btn" onClick={() => setShowEmoji(!showEmoji)}>
              😊
            </button>
            <button className="toolbar-btn">
              📎
            </button>
          </div>

          <div className="input-container">
            <input
              id="messageInput"
              type="text"
              placeholder="Введите сообщение..."
              value={inputValue}
              onChange={(e) => setInputValue(e.target.value)}
              onKeyPress={handleKeyPress}
            />
            <button id="sendBtn" onClick={sendMessage}>
              ➤
            </button>
          </div>
        </main>
      </div>

      {showEmoji && (
        <div className="emoji-picker show">
          <div className="emoji-grid">
            {EMOJIS.map((emoji, index) => (
              <span key={index} onClick={() => addEmoji(emoji)}>
                {emoji}
              </span>
            ))}
          </div>
        </div>
      )}

      {/* Общий музыкальный плеер YouTube + SoundCloud */}
      <div style={{ width: '300px', display: 'flex', flexDirection: 'column', gap: '10px' }}>
        <SharedMusicPlayer
          currentUserId={user.id}
          currentUserName={user.nickname}
        />
        
        {/* Информация о статусе */}
        <div className="bg-[var(--bg-secondary)] rounded-xl p-4 border border-[var(--border-light)]">
          <h4 className="text-sm font-semibold text-[var(--text-primary)] mb-2">👤 Ваш профиль</h4>
          <div className="flex items-center gap-2 mb-2">
            <span style={{ color: getStatusColor(user.status), fontSize: '20px' }}>
              {getStatusEmoji(user.status)}
            </span>
            <span className="text-sm font-medium" style={{ color: getStatusColor(user.status) }}>
              {user.status === 'guest' ? 'Гость' : user.status === 'participant' ? 'Участник' : user.status === 'king' ? 'Король' : 'Легенда'}
            </span>
          </div>
          <div className="text-xs text-[var(--text-muted)]">
            💰 Баллов: <span className="font-semibold text-[var(--accent-warning)]">{user.points}</span>
          </div>
          <div className="text-xs text-[var(--text-muted)] mt-1">
            💵 Инвестировано: <span className="font-semibold text-[var(--accent-secondary)]">{user.investedAmount}₽</span>
          </div>
        </div>
      </div>

      <CreateRoomModal
        isOpen={showCreateRoom}
        onClose={() => setShowCreateRoom(false)}
        onCreate={handleCreateRoom}
      />

      <PasswordModal
        isOpen={showPasswordModal}
        roomName={passwordRoom?.name || ''}
        onClose={() => { setShowPasswordModal(false); setPasswordRoom(null); setPasswordError(''); }}
        onSubmit={handlePasswordSubmit}
        error={passwordError}
      />

      <InviteModal
        isOpen={showInviteModal}
        roomName={currentRoom?.name || ''}
        users={DEMO_USERS.filter(u => u.id !== user.id)}
        onClose={() => setShowInviteModal(false)}
        onInvite={handleInvite}
      />
    </div>
  );
}
