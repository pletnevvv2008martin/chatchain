import { NextRequest, NextResponse } from 'next/server';

// Глобальное состояние музыкального плеера (хранится в памяти сервера)
// В продакшене лучше использовать Redis или базу данных

interface Track {
  id: string;
  title: string;
  thumbnail: string;
  duration: string;
  durationMs: number;
  source: 'youtube' | 'soundcloud';
  sourceId: string;
  addedBy: string;
  addedByName: string;
  addedAt: number;
}

interface MusicState {
  currentTrack: Track | null;
  queue: Track[];
  isPlaying: boolean;
  currentTime: number;
  startTime: number;
  volume: number;
  djUserId: string | null;
  lastUpdate: number;
}

// Глобальное состояние
declare global {
  // eslint-disable-next-line no-var
  var musicState: MusicState | undefined;
}

// Инициализация состояния
if (!globalThis.musicState) {
  globalThis.musicState = {
    currentTrack: null,
    queue: [],
    isPlaying: false,
    currentTime: 0,
    startTime: 0,
    volume: 100,
    djUserId: null,
    lastUpdate: Date.now(),
  };
}

const getMusicState = (): MusicState => {
  return globalThis.musicState!;
};

const updateMusicState = (updates: Partial<MusicState>) => {
  if (globalThis.musicState) {
    globalThis.musicState = {
      ...globalThis.musicState,
      ...updates,
      lastUpdate: Date.now(),
    };
  }
};

// GET - получить текущее состояние
export async function GET() {
  const state = getMusicState();

  let currentProgress = state.currentTime;
  if (state.isPlaying && state.currentTrack) {
    const elapsed = (Date.now() - state.startTime) / 1000;
    currentProgress = state.currentTime + elapsed;
  }

  return NextResponse.json({
    success: true,
    state: {
      currentTrack: state.currentTrack,
      queue: state.queue,
      isPlaying: state.isPlaying,
      currentTime: currentProgress,
      volume: state.volume,
      djUserId: state.djUserId,
      lastUpdate: state.lastUpdate,
    },
  });
}

// POST - управлять плеером
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { action, userId, userName, track, trackId, time, volume } = body;

    const state = getMusicState();

    switch (action) {
      case 'add_track': {
        if (!track) {
          return NextResponse.json({ success: false, error: 'No track provided' }, { status: 400 });
        }

        const newTrack: Track = {
          ...track,
          addedBy: userId,
          addedByName: userName || 'Unknown',
          addedAt: Date.now(),
        };

        if (!state.currentTrack) {
          updateMusicState({
            currentTrack: newTrack,
            isPlaying: true,
            currentTime: 0,
            startTime: Date.now(),
            djUserId: userId,
          });
        } else {
          updateMusicState({
            queue: [...state.queue, newTrack],
          });
        }

        return NextResponse.json({ success: true, state: getMusicState() });
      }

      case 'play':
        updateMusicState({
          isPlaying: true,
          startTime: Date.now(),
          currentTime: state.currentTime,
          djUserId: userId,
        });
        return NextResponse.json({ success: true, state: getMusicState() });

      case 'pause': {
        let pausedTime = state.currentTime;
        if (state.isPlaying) {
          const elapsed = (Date.now() - state.startTime) / 1000;
          pausedTime = state.currentTime + elapsed;
        }
        updateMusicState({
          isPlaying: false,
          currentTime: pausedTime,
          djUserId: userId,
        });
        return NextResponse.json({ success: true, state: getMusicState() });
      }

      case 'seek':
        if (typeof time === 'number') {
          updateMusicState({
            currentTime: time,
            startTime: Date.now(),
            djUserId: userId,
          });
        }
        return NextResponse.json({ success: true, state: getMusicState() });

      case 'next':
        if (state.queue.length > 0) {
          const nextTrack = state.queue[0];
          updateMusicState({
            currentTrack: nextTrack,
            queue: state.queue.slice(1),
            isPlaying: true,
            currentTime: 0,
            startTime: Date.now(),
            djUserId: userId,
          });
        } else {
          updateMusicState({
            currentTrack: null,
            isPlaying: false,
            currentTime: 0,
            djUserId: userId,
          });
        }
        return NextResponse.json({ success: true, state: getMusicState() });

      case 'remove':
        if (trackId) {
          updateMusicState({
            queue: state.queue.filter(t => t.id !== trackId),
          });
        }
        return NextResponse.json({ success: true, state: getMusicState() });

      case 'volume':
        if (typeof volume === 'number') {
          updateMusicState({ volume });
        }
        return NextResponse.json({ success: true, state: getMusicState() });

      case 'sync_time':
        if (typeof time === 'number') {
          updateMusicState({
            currentTime: time,
            startTime: Date.now(),
          });
        }
        return NextResponse.json({ success: true });

      case 'track_ended':
        if (state.queue.length > 0) {
          const nextTrack = state.queue[0];
          updateMusicState({
            currentTrack: nextTrack,
            queue: state.queue.slice(1),
            isPlaying: true,
            currentTime: 0,
            startTime: Date.now(),
          });
        } else {
          updateMusicState({
            currentTrack: null,
            isPlaying: false,
            currentTime: 0,
          });
        }
        return NextResponse.json({ success: true, state: getMusicState() });

      default:
        return NextResponse.json({ success: false, error: 'Unknown action' }, { status: 400 });
    }
  } catch {
    return NextResponse.json({ success: false, error: 'Server error' }, { status: 500 });
  }
}
