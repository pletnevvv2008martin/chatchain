'use client';

import { useState, useEffect, useCallback } from 'react';
import Header from '@/components/Header';
import {
  User,
  getUser,
  updateUser,
  getStatusEmoji,
  getStatusColor,
  getStatusName,
} from '@/lib/store';

interface GameCell {
  level: number;
  amount: number;
  status: 'available' | 'occupied' | 'completed';
  nextAvailable: Date | null;
}

interface PlayerStats {
  invested: number;
  earned: number;
  balance: number;
}

const INITIAL_CELLS: GameCell[] = [
  { level: 1, amount: 100, status: 'available', nextAvailable: null },
  { level: 2, amount: 200, status: 'available', nextAvailable: null },
  { level: 3, amount: 500, status: 'available', nextAvailable: null },
  { level: 4, amount: 1000, status: 'available', nextAvailable: null },
  { level: 5, amount: 2000, status: 'available', nextAvailable: null },
  { level: 6, amount: 5000, status: 'available', nextAvailable: null },
  { level: 7, amount: 10000, status: 'available', nextAvailable: null },
  { level: 8, amount: 25000, status: 'available', nextAvailable: null },
];

// Статусы для уровней вложений
const INVEST_THRESHOLDS = [
  { amount: 100, status: 'participant' as const, name: 'Участник', emoji: '⭐' },
  { amount: 10000, status: 'king' as const, name: 'Король', emoji: '👑' },
  { amount: 100000, status: 'legend' as const, name: 'Легенда', emoji: '🏆' },
];

export default function GamePage() {
  const [user, setUser] = useState<User | null>(null);
  const [cells, setCells] = useState<GameCell[]>(INITIAL_CELLS);
  const [stats, setStats] = useState<PlayerStats>({
    invested: 0,
    earned: 0,
    balance: 0,
  });

  // Инициализация
  useEffect(() => {
    const userData = getUser();
    setUser(userData);
    setStats({
      invested: userData.investedAmount,
      earned: userData.investedAmount * 0.5,
      balance: userData.investedAmount * 0.5,
    });
  }, []);

  // Обновление таймеров
  useEffect(() => {
    const interval = setInterval(() => {
      setCells(prev => prev.map(cell => {
        if (cell.nextAvailable && new Date() >= cell.nextAvailable) {
          return { ...cell, status: 'available', nextAvailable: null };
        }
        return cell;
      }));
    }, 1000);
    return () => clearInterval(interval);
  }, []);

  const formatTime = useCallback((date: Date): string => {
    const diff = date.getTime() - Date.now();
    if (diff <= 0) return '00:00:00';
    const hours = Math.floor(diff / (1000 * 60 * 60));
    const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
    const seconds = Math.floor((diff % (1000 * 60)) / 1000);
    return `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
  }, []);

  const getCurrentStatus = useCallback((invested: number) => {
    let status = { status: 'guest' as const, name: 'Гость', emoji: '👤' };
    for (const threshold of INVEST_THRESHOLDS) {
      if (invested >= threshold.amount) {
        status = { status: threshold.status, name: threshold.name, emoji: threshold.emoji };
      }
    }
    return status;
  }, []);

  const handleInvest = (level: number) => {
    const cell = cells.find(c => c.level === level);
    if (!cell || cell.status !== 'available' || !user) return;

    // Симуляция инвестирования
    const winAmount = cell.amount * 1.5;

    const newInvested = stats.invested + cell.amount;
    const newEarned = stats.earned + winAmount;
    const newBalance = stats.balance + winAmount - cell.amount;

    setStats({
      invested: newInvested,
      earned: newEarned,
      balance: newBalance,
    });

    // Обновляем пользователя
    const updatedUser = updateUser({ investedAmount: newInvested });
    setUser(updatedUser);

    // Установка таймера (1 минута для демо)
    const nextTime = new Date(Date.now() + 60 * 1000);

    setCells(prev => prev.map(c =>
      c.level === level
        ? { ...c, status: 'completed', nextAvailable: nextTime }
        : c
    ));

    const newStatus = getCurrentStatus(newInvested);
    showNotification(`✅ Вы заработали ${winAmount} ₽! ${newStatus.emoji} Статус: ${newStatus.name}`, 'success');
  };

  const handleWithdraw = () => {
    if (stats.balance >= 500) {
      showNotification(`✅ Заявка на вывод ${stats.balance} ₽ создана!`, 'success');
      setStats(prev => ({ ...prev, balance: 0 }));
    }
  };

  const showNotification = (message: string, type: 'success' | 'error' | 'info') => {
    const notification = document.createElement('div');
    notification.className = `notification ${type}`;
    notification.textContent = message;
    document.body.appendChild(notification);
    setTimeout(() => notification.remove(), 3000);
  };

  if (!user) {
    return <div className="app-container">Загрузка...</div>;
  }

  const currentStatus = getCurrentStatus(stats.invested);

  return (
    <div className="app-container">
      <Header nickname={user.nickname} onlineCount={3} />

      <main className="game-content">
        {/* Карточка статистики с новым статусом */}
        <div className="game-stats-card">
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '20px' }}>
            <h2 style={{ margin: 0 }}>📊 Моя статистика</h2>
            <div style={{
              display: 'flex',
              alignItems: 'center',
              gap: '8px',
              padding: '8px 16px',
              background: `linear-gradient(135deg, ${getStatusColor(currentStatus.status)}, ${currentStatus.status === 'legend' ? '#d946ef' : currentStatus.status === 'king' ? '#fbbf24' : '#60a5fa'})`,
              borderRadius: '20px',
              color: 'white',
              fontWeight: '600',
            }}>
              <span style={{ fontSize: '20px' }}>{currentStatus.emoji}</span>
              <span>{currentStatus.name}</span>
            </div>
          </div>

          <div className="stats-grid">
            <div className="stat-item">
              <span className="stat-label">Инвестировано</span>
              <span className="stat-value">{stats.invested.toLocaleString()} ₽</span>
            </div>
            <div className="stat-item">
              <span className="stat-label">Выиграно</span>
              <span className="stat-value">{stats.earned.toLocaleString()} ₽</span>
            </div>
            <div className="stat-item highlight">
              <span className="stat-label">Баланс</span>
              <span className="stat-value">{stats.balance.toLocaleString()} ₽</span>
            </div>
          </div>

          {/* Прогресс до следующего статуса */}
          {currentStatus.status !== 'legend' && (
            <div style={{ marginTop: '20px', padding: '16px', background: 'var(--bg-tertiary)', borderRadius: '12px' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '8px' }}>
                <span>Прогресс до следующего статуса</span>
                <span style={{ fontWeight: '600', color: 'var(--accent-primary)' }}>
                  {currentStatus.status === 'guest' && `⭐ Участник (100 ₽)`}
                  {currentStatus.status === 'participant' && `👑 Король (10,000 ₽)`}
                  {currentStatus.status === 'king' && `🏆 Легенда (100,000 ₽)`}
                </span>
              </div>
              <div className="progress-bar" style={{ height: '12px', borderRadius: '6px' }}>
                <div
                  className="progress-fill"
                  style={{
                    width: `${Math.min(
                      currentStatus.status === 'guest'
                        ? (stats.invested / 100) * 100
                        : currentStatus.status === 'participant'
                          ? (stats.invested / 10000) * 100
                          : (stats.invested / 100000) * 100,
                      100
                    )}%`,
                    borderRadius: '6px'
                  }}
                />
              </div>
            </div>
          )}

          {stats.balance >= 500 && (
            <button className="withdraw-btn" onClick={handleWithdraw}>
              💸 Вывести {stats.balance.toLocaleString()} ₽
            </button>
          )}
        </div>

        {/* Информация о статусах */}
        <div className="game-stats-card" style={{ marginTop: '20px' }}>
          <h2>🏆 Система статусов</h2>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: '16px', marginTop: '16px' }}>
            <div style={{ padding: '16px', background: 'var(--bg-tertiary)', borderRadius: '12px', textAlign: 'center' }}>
              <div style={{ fontSize: '32px', marginBottom: '8px' }}>👤</div>
              <div style={{ fontWeight: '600' }}>Гость</div>
              <div style={{ fontSize: '12px', color: 'var(--text-muted)' }}>до 100 ₽</div>
            </div>
            <div style={{ padding: '16px', background: 'linear-gradient(135deg, rgba(59, 130, 246, 0.2), rgba(96, 165, 250, 0.1))', borderRadius: '12px', textAlign: 'center', border: '2px solid var(--accent-primary)' }}>
              <div style={{ fontSize: '32px', marginBottom: '8px' }}>⭐</div>
              <div style={{ fontWeight: '600', color: 'var(--accent-primary)' }}>Участник</div>
              <div style={{ fontSize: '12px', color: 'var(--text-muted)' }}>от 100 ₽</div>
            </div>
            <div style={{ padding: '16px', background: 'linear-gradient(135deg, rgba(245, 158, 11, 0.2), rgba(251, 191, 36, 0.1))', borderRadius: '12px', textAlign: 'center', border: '2px solid var(--accent-warning)' }}>
              <div style={{ fontSize: '32px', marginBottom: '8px' }}>👑</div>
              <div style={{ fontWeight: '600', color: 'var(--accent-warning)' }}>Король</div>
              <div style={{ fontSize: '12px', color: 'var(--text-muted)' }}>от 10,000 ₽</div>
            </div>
            <div style={{ padding: '16px', background: 'linear-gradient(135deg, rgba(236, 72, 153, 0.2), rgba(217, 70, 239, 0.1))', borderRadius: '12px', textAlign: 'center', border: '2px solid var(--accent-love)' }}>
              <div style={{ fontSize: '32px', marginBottom: '8px' }}>🏆</div>
              <div style={{ fontWeight: '600', color: 'var(--accent-love)' }}>Легенда</div>
              <div style={{ fontSize: '12px', color: 'var(--text-muted)' }}>от 100,000 ₽</div>
            </div>
          </div>
        </div>

        {/* Игровые ячейки */}
        <div className="cells-grid" style={{ marginTop: '20px' }}>
          {cells.map((cell) => (
            <div
              key={cell.level}
              className="game-cell"
              data-status={cell.status}
            >
              <div className="cell-header">
                <span className="cell-level">Уровень {cell.level}</span>
                <span className={`cell-badge status-${cell.status}`}>
                  {cell.status === 'available' && 'Доступно'}
                  {cell.status === 'occupied' && 'Ожидание'}
                  {cell.status === 'completed' && 'Завершено'}
                </span>
              </div>

              <div className="cell-amount">
                <span className="amount-value">{cell.amount.toLocaleString()}</span>
                <span className="amount-currency">₽</span>
              </div>

              <div className="cell-multiplier">
                x1.5 ({(cell.amount * 1.5).toLocaleString()} ₽)
              </div>

              <div className="cell-timer">
                {cell.nextAvailable ? (
                  <>
                    <span className="timer-label">Доступна через:</span>
                    <span className="timer-value">{formatTime(cell.nextAvailable)}</span>
                  </>
                ) : (
                  <span className="timer-available">Доступно сейчас</span>
                )}
              </div>

              <button
                className="join-cell-btn"
                onClick={() => handleInvest(cell.level)}
                disabled={cell.status !== 'available'}
              >
                Инвестировать
              </button>
            </div>
          ))}
        </div>

        <div style={{ marginTop: '20px', textAlign: 'center', opacity: 0.7 }}>
          <p>⚠️ Это демо-версия игры. Реальные деньги не используются.</p>
        </div>
      </main>
    </div>
  );
}
