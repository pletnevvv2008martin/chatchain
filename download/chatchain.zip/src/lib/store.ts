// Типы данных
export interface User {
  id: string;
  nickname: string;
  points: number;
  investedAmount: number;
  status: 'guest' | 'participant' | 'king' | 'legend';
}

export interface Message {
  id: string;
  userId: string;
  user: string;
  content: string;
  time: string;
  type: 'text' | 'image' | 'system';
  userStatus?: 'guest' | 'participant' | 'king' | 'legend';
}

export interface Room {
  id: string;
  name: string;
  password?: string;
  createdBy: string;
  users: string[];
  messages: Message[];
  maxUsers: number;
  isLobby: boolean;
  lobbyNumber?: number;
}

export interface Track {
  id: string;
  title: string;
  artist: string;
  duration: number;
  cover?: string;
  addedBy: string;
  isPaid: boolean;
  likes: number;
}

export interface MusicState {
  currentTrack: Track | null;
  queue: Track[];
  paidQueue: Track[];
  isPlaying: boolean;
  progress: number;
}

// Утилиты для localStorage
const STORAGE_KEYS = {
  USER: 'chatchain_user',
  ROOMS: 'chatchain_rooms',
  MESSAGES: 'chatchain_messages',
};

// Генерация ID
export const generateId = () => Math.random().toString(36).substr(2, 9);

// Получение статуса по сумме вложений
export const getStatusByAmount = (amount: number): 'guest' | 'participant' | 'king' | 'legend' => {
  if (amount >= 100000) return 'legend';
  if (amount >= 10000) return 'king';
  if (amount >= 100) return 'participant';
  return 'guest';
};

// Название статуса
export const getStatusName = (status: 'guest' | 'participant' | 'king' | 'legend'): string => {
  const names = {
    guest: 'Гость',
    participant: 'Участник',
    king: 'Король',
    legend: 'Легенда',
  };
  return names[status];
};

// Эмодзи статуса
export const getStatusEmoji = (status: 'guest' | 'participant' | 'king' | 'legend'): string => {
  const emojis = {
    guest: '👤',
    participant: '⭐',
    king: '👑',
    legend: '🏆',
  };
  return emojis[status];
};

// Цвет статуса
export const getStatusColor = (status: 'guest' | 'participant' | 'king' | 'legend'): string => {
  const colors = {
    guest: '#64748b',
    participant: '#3b82f6',
    king: '#f59e0b',
    legend: '#ec4899',
  };
  return colors[status];
};

// Работа с пользователем
export const getUser = (): User => {
  if (typeof window === 'undefined') {
    return {
      id: '',
      nickname: 'Гость',
      points: 100,
      investedAmount: 0,
      status: 'guest',
    };
  }

  const stored = localStorage.getItem(STORAGE_KEYS.USER);
  if (stored) {
    return JSON.parse(stored);
  }

  const newUser: User = {
    id: generateId(),
    nickname: `Гость_${Math.floor(Math.random() * 10000)}`,
    points: 100,
    investedAmount: 0,
    status: 'guest',
  };

  localStorage.setItem(STORAGE_KEYS.USER, JSON.stringify(newUser));
  return newUser;
};

export const updateUser = (updates: Partial<User>): User => {
  if (typeof window === 'undefined') {
    return {
      id: '',
      nickname: 'Гость',
      points: 100,
      investedAmount: 0,
      status: 'guest',
    };
  }

  const user = getUser();
  const updatedUser = { ...user, ...updates };

  if (updates.investedAmount !== undefined) {
    updatedUser.status = getStatusByAmount(updates.investedAmount);
  }

  localStorage.setItem(STORAGE_KEYS.USER, JSON.stringify(updatedUser));
  return updatedUser;
};

// Работа с комнатами
export const getRooms = (): Room[] => {
  if (typeof window === 'undefined') return [];

  const stored = localStorage.getItem(STORAGE_KEYS.ROOMS);
  if (stored) {
    return JSON.parse(stored);
  }

  // Создаём первое лобби по умолчанию
  const defaultLobby: Room = {
    id: 'lobby-1',
    name: 'Общий чат #1',
    createdBy: 'system',
    users: [],
    messages: [],
    maxUsers: 100,
    isLobby: true,
    lobbyNumber: 1,
  };

  localStorage.setItem(STORAGE_KEYS.ROOMS, JSON.stringify([defaultLobby]));
  return [defaultLobby];
};

export const saveRooms = (rooms: Room[]) => {
  if (typeof window === 'undefined') return;
  localStorage.setItem(STORAGE_KEYS.ROOMS, JSON.stringify(rooms));
};

export const createRoom = (name: string, password: string, userId: string): Room => {
  const rooms = getRooms();
  const newRoom: Room = {
    id: generateId(),
    name,
    password: password || undefined,
    createdBy: userId,
    users: [userId],
    messages: [],
    maxUsers: 50,
    isLobby: false,
  };

  saveRooms([...rooms, newRoom]);
  return newRoom;
};

export const getAvailableLobby = (): Room => {
  let rooms = getRooms();
  let availableLobby = rooms.find(r => r.isLobby && r.users.length < 100);

  if (!availableLobby) {
    // Создаём новое лобби
    const lobbyNumbers = rooms
      .filter(r => r.isLobby)
      .map(r => r.lobbyNumber || 0);
    const nextNumber = Math.max(...lobbyNumbers, 0) + 1;

    availableLobby = {
      id: `lobby-${nextNumber}`,
      name: `Общий чат #${nextNumber}`,
      createdBy: 'system',
      users: [],
      messages: [],
      maxUsers: 100,
      isLobby: true,
      lobbyNumber: nextNumber,
    };

    rooms = [...rooms, availableLobby];
    saveRooms(rooms);
  }

  return availableLobby;
};

export const joinRoom = (roomId: string, userId: string, password?: string): { success: boolean; error?: string; room?: Room } => {
  const rooms = getRooms();
  const room = rooms.find(r => r.id === roomId);

  if (!room) {
    return { success: false, error: 'Комната не найдена' };
  }

  if (room.password && room.password !== password) {
    return { success: false, error: 'Неверный пароль' };
  }

  if (room.users.length >= room.maxUsers) {
    return { success: false, error: 'Комната заполнена' };
  }

  if (!room.users.includes(userId)) {
    room.users.push(userId);
    saveRooms(rooms);
  }

  return { success: true, room };
};

export const leaveRoom = (roomId: string, userId: string) => {
  const rooms = getRooms();
  const room = rooms.find(r => r.id === roomId);

  if (room && !room.isLobby) {
    room.users = room.users.filter(id => id !== userId);
    if (room.users.length === 0) {
      // Удаляем пустую комнату
      saveRooms(rooms.filter(r => r.id !== roomId));
    } else {
      saveRooms(rooms);
    }
  }
};

// Работа с сообщениями
export const addMessageToRoom = (roomId: string, message: Message) => {
  if (typeof window === 'undefined') return;

  const rooms = getRooms();
  const room = rooms.find(r => r.id === roomId);

  if (room) {
    room.messages.push(message);
    // Храним только последние 200 сообщений
    if (room.messages.length > 200) {
      room.messages = room.messages.slice(-200);
    }
    saveRooms(rooms);
  }
};

// Демо-треки для музыкального плеера
export const DEMO_TRACKS: Omit<Track, 'addedBy' | 'isPaid' | 'likes'>[] = [
  { id: '1', title: 'Blinding Lights', artist: 'The Weeknd', duration: 200, cover: '/img/unnamed_1_1771144713.png' },
  { id: '2', title: 'Shape of You', artist: 'Ed Sheeran', duration: 234, cover: '/img/unnamed_1_1771144713.png' },
  { id: '3', title: 'Dance Monkey', artist: 'Tones and I', duration: 210, cover: '/img/unnamed_1_1771144713.png' },
  { id: '4', title: 'Someone Like You', artist: 'Adele', duration: 285, cover: '/img/unnamed_1_1771144713.png' },
  { id: '5', title: 'Uptown Funk', artist: 'Bruno Mars', duration: 270, cover: '/img/unnamed_1_1771144713.png' },
  { id: '6', title: 'Bad Guy', artist: 'Billie Eilish', duration: 194, cover: '/img/unnamed_1_1771144713.png' },
  { id: '7', title: 'Starboy', artist: 'The Weeknd', duration: 230, cover: '/img/unnamed_1_1771144713.png' },
  { id: '8', title: 'Levitating', artist: 'Dua Lipa', duration: 203, cover: '/img/unnamed_1_1771144713.png' },
  { id: '9', title: 'Watermelon Sugar', artist: 'Harry Styles', duration: 174, cover: '/img/unnamed_1_1771144713.png' },
  { id: '10', title: 'drivers license', artist: 'Olivia Rodrigo', duration: 242, cover: '/img/unnamed_1_1771144713.png' },
];
