import { NextRequest, NextResponse } from 'next/server';

interface User {
  id: string;
  nickname: string;
  email?: string;
  password?: string;
  createdAt: number;
  role?: 'user' | 'admin';
}

interface StoredUsers {
  users: User[];
}

declare global {
  var authUsers: StoredUsers | undefined;
}

if (!globalThis.authUsers) {
  globalThis.authUsers = { users: [] };
}

const generateId = () => Math.random().toString(36).substr(2, 12);

// Предустановленные админы
const ADMIN_ACCOUNTS = [
  { nickname: 'Martin', password: 'admin123', role: 'admin' as const },
];

// Автосоздание админов при первом запуске
const initAdmins = () => {
  ADMIN_ACCOUNTS.forEach(admin => {
    const exists = globalThis.authUsers!.users.find(
      u => u.nickname.toLowerCase() === admin.nickname.toLowerCase()
    );
    if (!exists) {
      globalThis.authUsers!.users.push({
        id: `admin-${generateId()}`,
        nickname: admin.nickname,
        password: admin.password,
        createdAt: Date.now(),
        role: admin.role,
      });
      console.log(`✅ Admin created: ${admin.nickname}`);
    }
  });
};

// Инициализация админов
initAdmins();

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { action, nickname, email, password } = body;

    if (action === 'register') {
      const existingUser = globalThis.authUsers.users.find(
        u => u.nickname.toLowerCase() === nickname.toLowerCase()
      );

      if (existingUser) {
        return NextResponse.json(
          { success: false, error: 'Этот никнейм занят' },
          { status: 400 }
        );
      }

      if (email) {
        const existingEmail = globalThis.authUsers.users.find(
          u => u.email?.toLowerCase() === email.toLowerCase()
        );
        if (existingEmail) {
          return NextResponse.json(
            { success: false, error: 'Этот email уже используется' },
            { status: 400 }
          );
        }
      }

      const newUser: User = {
        id: `user-${generateId()}`,
        nickname,
        email: email || undefined,
        password: password || undefined,
        createdAt: Date.now(),
        role: 'user',
      };

      globalThis.authUsers.users.push(newUser);

      return NextResponse.json({
        success: true,
        user: {
          id: newUser.id,
          nickname: newUser.nickname,
          email: newUser.email,
        },
      });
    }

    if (action === 'login') {
      const user = globalThis.authUsers.users.find(
        u => u.nickname.toLowerCase() === nickname.toLowerCase()
      );

      if (!user) {
        return NextResponse.json(
          { success: false, error: 'Пользователь не найден' },
          { status: 400 }
        );
      }

      if (user.password && user.password !== password) {
        return NextResponse.json(
          { success: false, error: 'Неверный пароль' },
          { status: 400 }
        );
      }

      return NextResponse.json({
        success: true,
        user: {
          id: user.id,
          nickname: user.nickname,
          email: user.email,
          role: user.role,
        },
      });
    }

    if (action === 'check') {
      const { userId } = body;
      const user = globalThis.authUsers.users.find(u => u.id === userId);

      if (user) {
        return NextResponse.json({
          success: true,
          user: {
            id: user.id,
            nickname: user.nickname,
            email: user.email,
            role: user.role,
          },
        });
      }

      return NextResponse.json({ success: false });
    }

    return NextResponse.json({ success: false, error: 'Неизвестное действие' }, { status: 400 });
  } catch {
    return NextResponse.json({ success: false, error: 'Ошибка сервера' }, { status: 500 });
  }
}

export async function GET() {
  return NextResponse.json({
    usersCount: globalThis.authUsers.users.length,
    admins: ADMIN_ACCOUNTS.map(a => ({ nickname: a.nickname })),
  });
}
